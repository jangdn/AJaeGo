/*
 * This package contains the model for the moves and the defined rating
 * constants
 */
package connect4.AI.Model;
